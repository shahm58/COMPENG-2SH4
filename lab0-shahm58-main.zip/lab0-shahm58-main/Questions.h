#include <stdio.h>
#include <stdlib.h>

//Question 1 definitions and prototypes
int addFunction(int input1, int input2);
