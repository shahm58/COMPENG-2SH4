#include <stdio.h>
#include <stdlib.h>

#include "Questions.h"



int addFunction(int input1, int input2){
	int sum = 0;
	sum = input1 + input2;
	return (sum);
}

